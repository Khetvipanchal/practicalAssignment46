// categories.php
$result = mysqli_query($conn, "SELECT * FROM categories");
while ($row = mysqli_fetch_assoc($result)) {
    echo "<a href='products.php?category_id={$row['id']}'>{$row['name']}</a><br>";
}

