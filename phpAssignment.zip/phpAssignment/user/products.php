<?php 
// products.php (server-side pagination logic)
$category_id = $_GET['category_id'];
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$result = mysqli_query($conn, "SELECT * FROM products WHERE category_id = $category_id LIMIT $limit OFFSET $offset");
// Use AJAX to fetch and display products dynamically

