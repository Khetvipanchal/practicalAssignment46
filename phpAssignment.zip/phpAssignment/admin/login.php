// admin_login.php
<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Validate admin credentials
    if ($username == 'admin' && $password == 'password123') {
        $_SESSION['admin'] = $username;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Invalid credentials!";
    }
}
?>
<!-- HTML Login Form -->
<form method="POST">
    <input type="text" name="username" placeholder="Admin Username">
    <input type="password" name="password" placeholder="Admin Password">
    <input type="submit" value="Login">
</form>
