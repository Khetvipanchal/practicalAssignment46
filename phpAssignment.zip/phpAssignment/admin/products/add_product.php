<?php 
if(isset($_FILES['product_image'])) {
    $target_dir = "uploads/";
    $target_files = $target_dir .= basename($_FILES["product_image"]["name"]);

    $img = imagecreatefromjpeg($_FILES['product_image']['tmp_name']);
    $width = imagesx($img);
    $height = imagesy($img);
    $new_width = 150;
    $new_height = floor($height * ($new_width / $width));

    $tmp_img = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    imagejpeg($tmp_img, $target_file, 100);
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="text" name="product_name" placeholder="Product Name">
    <input type="file" name="product_image">
    <button type="submit">Add Product</button>
</form>