<?php
// Include the database connection file
include '../includes/config.php';  // Ensure this path is correct

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_name = $_POST['category_name'];

    // Make sure the database connection ($conn) exists
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Insert the category into the database
    $query = "INSERT INTO categories (name) VALUES ('$category_name')";
    if (mysqli_query($conn, $query)) {
        echo "Category added successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<form method="POST">
    <input type="text" name="category_name" placeholder="Category Name">
    <button type="submit">Add Category</button>
</form>
