// write_students.php
<?
$result = mysqli_query($conn, "SELECT * FROM students");
$xml = new SimpleXMLElement('<students/>');
while ($row = mysqli_fetch_assoc($result)) {
    $student = $xml->addChild('student');
    $student->addChild('name', $row['name']);
    $student->addChild('age', $row['age']);
}
$xml->asXML('students.xml');
