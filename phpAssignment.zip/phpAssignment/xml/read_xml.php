// read_students.php
<?
$xml = simplexml_load_file("students.xml");
foreach ($xml->student as $student) {
    $query = "INSERT INTO students (name, age) VALUES ('$student->name', '$student->age')";
    mysqli_query($conn, $query);
}
